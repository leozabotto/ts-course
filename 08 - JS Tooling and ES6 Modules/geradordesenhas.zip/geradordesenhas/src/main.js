import formGeraSenha from './modules/formGeraSenha';
import './assets/css/style.css';
formGeraSenha();
